/*	Benjamin DELPY `gentilkiwi`
	https://blog.gentilkiwi.com
	benjamin@gentilkiwi.com
	Licence : https://creativecommons.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_dPApi.h"

NTSTATUS kuhl_m_dPApi_wifi(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_dPApi_wwan(int argc, wchar_t * argv[]);
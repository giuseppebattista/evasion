/*	Benjamin DELPY `gentilkiwi`
	http://blog.gentilkiwi.com
	benjamin@gentilkiwi.com
	Licence : http://creativecommons.org/licenses/by/3.0/fr/
*/
#pragma once
#include "kuhl_m.h"
#include "../modules/kull_m_file.h"
#include "../modules/kull_m_dPApi.h"

const KUHL_M kuhl_m_dPApi;

NTSTATUS kuhl_m_dPApi_masTerKeYs(int argc, wchar_t * argv[]);